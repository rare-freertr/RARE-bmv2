#!/bin/sh
kill -9 `pidof java`
