#!/bin/sh
echo compiling
ikvmc -out:rtr.bin rtr.jar
