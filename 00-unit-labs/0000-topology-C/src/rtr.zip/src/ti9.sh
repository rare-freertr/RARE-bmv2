#!/bin/sh
java -Xmx256m -jar rtr.jar test tester intop9 retry remote intop9.ini randord $1 $2 $3 $4 $5 $6 $7 $8
