
import cfg.cfgInit;

/**
 * main class for the router
 *
 * @author matecsaba
 */
public class router {

    /**
     * this is the main method for the jar file
     *
     * @param args command line parameters
     */
    public static void main(String[] args) {
        cfgInit.doMain(args);
    }

}
