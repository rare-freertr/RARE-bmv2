#!/bin/sh
./c.sh
./r.sh
