package rtr;

/**
 * bfd client
 *
 * @author matecsaba
 */
public interface rtrBfdClnt {

    /**
     * notified about bfd peer down
     */
    public void bfdPeerDown();

}
