package ifc;

/**
 * bridge router handler
 *
 * @author matecsaba
 */
public interface ifcBridgeRtr {

    /**
     * bridge changed
     */
    public void bridgeChanged();

}
